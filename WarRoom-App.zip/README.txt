ME NOT THAT KIND OF ORC — WAR ROOM APP

HOW TO LAUNCH
1. Keep this entire folder together.
2. Double-click "Launch War Room.bat".
3. The app opens in your default browser.

IMPORTANT
- Do not move index.html away from the assets folder.
- Future War Room updates should replace files inside THIS SAME app folder.
- Your raid selections and attendance are saved by the browser on that computer.

CURRENT BUILD
Canonical Build 1.0
