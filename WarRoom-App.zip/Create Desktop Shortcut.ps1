﻿$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath("Desktop")
$shortcutPath = Join-Path $desktop "Me Not That Kind Of Orc - War Room.lnk"
$target = Join-Path $root "Launch War Room.bat"
$icon = Join-Path $root "assets\icons\WarRoom.ico"
$ws = New-Object -ComObject WScript.Shell
$s = $ws.CreateShortcut($shortcutPath)
$s.TargetPath = $target
$s.WorkingDirectory = $root
$s.IconLocation = "$icon,0"
$s.Description = "Me Not That Kind Of Orc - War Room"
$s.Save()
Write-Host "Desktop shortcut created."
