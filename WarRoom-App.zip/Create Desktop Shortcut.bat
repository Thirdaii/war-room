@echo off
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Create Desktop Shortcut.ps1"
echo.
echo Desktop shortcut created with the War Room Orc icon.
pause
