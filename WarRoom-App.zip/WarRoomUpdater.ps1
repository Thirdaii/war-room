﻿param(
    [switch]$SkipUpdate
)

$ErrorActionPreference = "Stop"
$AppRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoOwner = "Thirdaii"
$RepoName = "war-room"
$AssetName = "WarRoom-App.zip"
$VersionFile = Join-Path $AppRoot "version.json"
$IndexFile = Join-Path $AppRoot "index.html"

function Write-Status([string]$Message) {
    Write-Host "[WAR ROOM] $Message" -ForegroundColor DarkRed
}

function Get-LocalVersion {
    try {
        if (Test-Path $VersionFile) {
            $v = Get-Content $VersionFile -Raw | ConvertFrom-Json
            if ($v.version) { return [version]$v.version }
        }
    } catch {}
    return [version]"0.0.0"
}

function Start-WarRoom {
    if (-not (Test-Path $IndexFile)) {
        throw "index.html was not found in $AppRoot"
    }
    Write-Status "Opening the War Room..."
    Start-Process $IndexFile
}

if ($SkipUpdate) {
    Start-WarRoom
    exit 0
}

$localVersion = Get-LocalVersion
Write-Status "Installed version: $localVersion"
Write-Status "Checking GitHub for updates..."

try {
    $headers = {
        "User-Agent" = "Me-Not-That-Kind-Of-Orc-War-Room"
        "Accept" = "application/vnd.github+json"
    }
    $latestUrl = "https://api.github.com/repos/$RepoOwner/$RepoName/releases/latest"
    $release = Invoke-RestMethod -Uri $latestUrl -Headers $headers -Method Get -TimeoutSec 15

    $tag = [string]$release.tag_name
    $cleanTag = $tag.TrimStart("v","V")
    $remoteVersion = [version]$cleanTag

    Write-Status "Latest GitHub version: $remoteVersion"

    if ($remoteVersion -le $localVersion) {
        Write-Status "War Room is up to date."
        Start-WarRoom
        exit 0
    }

    $asset = $release.assets | Where-Object { $_.name -eq $AssetName } | Select-Object -First 1
    if (-not $asset) {
        Write-Warning "Release $tag exists but does not contain $AssetName."
        Write-Status "Launching installed version instead."
        Start-WarRoom
        exit 0
    }

    Write-Status "Update found: $localVersion -> $remoteVersion"
    $tempRoot = Join-Path $env:TEMP ("WarRoomUpdate_" + [guid]::NewGuid().ToString("N"))
    $zipPath = Join-Path $tempRoot $AssetName
    $extractPath = Join-Path $tempRoot "extract"

    New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
    New-Item -ItemType Directory -Path $extractPath -Force | Out-Null

    Write-Status "Downloading update..."
    Invoke-WebRequest -Uri $asset.browser_download_url -Headers $headers -OutFile $zipPath -UseBasicParsing -TimeoutSec 60

    Write-Status "Extracting update..."
    Expand-Archive -Path $zipPath -DestinationPath $extractPath -Force

    # Releases should contain app files at ZIP root. If a single folder is present,
    # automatically use that folder as the source.
    $source = $extractPath
    $children = @(Get-ChildItem $extractPath)
    if ($children.Count -eq 1 -and $children[0].PSIsContainer) {
        $source = $children[0].FullName
    }

    if (-not (Test-Path (Join-Path $source "index.html"))) {
        throw "Downloaded update did not contain index.html."
    }

    Write-Status "Installing update..."
    # Preserve the updater/launchers while replacing the application payload.
    Get-ChildItem $source -Force | ForEach-Object {
        $destination = Join-Path $AppRoot $_.Name
        if ($_.PSIsContainer) {
            if (Test-Path $destination) {
                Copy-Item (Join-Path $_.FullName "*") $destination -Recurse -Force
            } else {
                Copy-Item $_.FullName $destination -Recurse -Force
            }
        } else {
            Copy-Item $_.FullName $destination -Force
        }
    }

    Remove-Item $tempRoot -Recurse -Force -ErrorAction SilentlyContinue
    Write-Status "Update installed successfully."
    Start-WarRoom
}
catch {
    Write-Warning ("Update check failed: " + $_.Exception.Message)
    Write-Status "Launching your installed War Room build."
    Start-WarRoom
}
