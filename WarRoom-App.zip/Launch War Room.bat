@echo off
setlocal
cd /d "%~dp0"
title Me Not That Kind Of Orc - War Room
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0WarRoomUpdater.ps1"
if errorlevel 1 (
  echo.
  echo The War Room updater encountered an error.
  echo Launching installed build directly...
  start "" "%~dp0index.html"
  pause
)
